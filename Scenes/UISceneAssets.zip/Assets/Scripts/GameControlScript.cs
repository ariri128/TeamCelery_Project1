using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameControlScript : MonoBehaviour
{
    public int score = 1200;
    public int bullets = 0;
    public int num = 7;
    public int round = 3;

    public UIUpdateScript uiUpdateScript;

    void Start()
    {
        uiUpdateScript.currentCollections = num; 
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.W))
        {
            uiUpdateScript.ScoreUpdate();
            uiUpdateScript.RoundUpdate();
            uiUpdateScript.BulletShot();
            uiUpdateScript.ShowCollectedDucks();
        }
        else if (Input.GetKeyDown(KeyCode.E))
        {
            uiUpdateScript.ReloadBullets();
            uiUpdateScript.HideAllDucks();
        }
        
    }
     
}
